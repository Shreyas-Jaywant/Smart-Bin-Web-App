<?php
$host="localhost";
$username="id";
$password="password";
$database="db";
$con = mysqli_connect("$host","$username","$password","$database");
/*if(!$con)
{
    die("DataBase Connection Failed" .mysqli_error($con));
    exit();
}*/
$db = "db";
$dbs = mysqli_select_db($con,$db);  
if(!$dbs)
{
    die("Databaase Selection Failed :" .mysqli_error($con));;
    exit();
}
$ID=mysqli_real_escape_string($con,$_GET['ID']);
$AREA=mysqli_real_escape_string($con,$_GET['Area']);
$email=mysqli_real_escape_string($con,$_GET['email']);
$complaint=mysqli_real_escape_string($con,$_GET['complaint']);
$Remark=mysqli_real_escape_string($con,$_GET['Remark']);

$Final_status=mysqli_real_escape_string($con,$_GET['Final_status']);
$Action=mysqli_real_escape_string($con,$_GET['Action']);
$query= "INSERT INTO complaints(ID,Area,email,complaint,Remark,Final_status,Action) VALUES (NULL,'$AREA','$email','$complaint','$Remark','$Final_status','$Action')";
//printf("<p>ID of the previous record: %d.</p>",$mysqli->insert_id);
if(mysqli_query($con,$query))
{
    echo "Record Added Successfully ";
}
else
{
    echo "Error: Could not able to execute" .$query." ".mysqli_error($con); 
}
mysqli_close($con);
?>
