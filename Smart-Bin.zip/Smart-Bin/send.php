<?php

$con=mysqli_connect("localhost","id","password","db");

$Item=$_POST["Item"];

mysqli_query($con,"INSERT INTO item_list(Item)  VALUES('$Item')");
?>