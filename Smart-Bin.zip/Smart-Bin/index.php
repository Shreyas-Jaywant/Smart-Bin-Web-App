<?php
session_start();
include('includes/header.php');
include('includes/navbar.php');

?>
<style>
    .back{height:91.8vh;background-color:#E9D700}
</style>
<div class="back">
    <div class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   <center><b style="color:red;"><h1>Confirm to Logout</h1></b></center>
                   <br><br><br><br><br><br>
                    <center><h3>Keep Clean</h3></h3></center>
                    
                </div>
    
            </div>
        </div>
    </div>
</div>
<?php
include('includes/footer.php');
?>