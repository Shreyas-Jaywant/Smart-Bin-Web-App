<?php

include('authentication.php');


  if(isset($_POST['updated']))
  {
$ID=$_GET['ID'];
$STATUS=$_POST['status'];
$Remark=$_POST['remark'];

$sql=mysqli_query($con, "update complaints set STATUS='$STATUS',Remark='$Remark' where ID='$ID'");


echo "<script>alert('Complaint details updated successfully and Mail Sent');</script>";
  
  }
?>
<script language="javascript" type="text/javascript">
function f2()
{
window.close();
}ser
function f3()
{
window.print(); 
}
</script>
<div style="margin-left:50px;">
 <form name="updateticket" id="updatecomplaint" method="post"> 
<table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td  >&nbsp;</td>
      <td >&nbsp;</td>
    </tr>
    <tr height="50">
      <td><b>Complaint ID</b></td>
      <td><?php echo htmlentities($_GET['ID']); ?></td>
    </tr>
    <tr height="50">
      <td><b>Email Id</b></td>
      <td>
   
<select name="email">
<option>--- Select ---</option>
 <?php
 $query = "SELECT email FROM complaints";
 $query_run = mysqli_query($con, $query);
 if (mysqli_num_rows($query_run) > 0) {
 foreach ($query_run as $row) {
 ?>
 <option>
 <?= $row['email'] ?>
 </option>
 <?php }
 } else { ?> <?php } ?>
 else
</select>
      <td>
    </tr>
    <tr height="50">
      <td><b>Status</b></td>
      <td><select name="status" required="required">
      <option value="">Select Status</option>
      <option value="in process">In Process</option>
    <option value="closed">Closed</option>
        
      </select></td>
    </tr>


      <tr height="50">
      <td><b>Remark</b></td>
      <td><textarea name="remark" cols="50" rows="10" required="required"></textarea></td>
    </tr>
    


        <tr height="50">
      <td>&nbsp;</td>
      <td><input type="submit" name="updated" value="Submit"></td>
    </tr>



       <tr><td colspan="2">&nbsp;</td></tr>
    
    <tr>
  <td></td>
      <td >   
      <input name="Submit2" type="submit" class="txtbox4" value="Close this window " onClick="return f2();" style="cursor: pointer;"  /></td>
    </tr>
   

 
</table>
 </form>
</div>
<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
if(isset($_POST['updated']))
{
$email=$_POST['email'];


require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


  $mail = new PHPMailer;
  $mail->SMTPDebug=0;
  $mail->isSMTP();
  $mail->Host = 'smtp.gmail.com';
  $mail->SMTPAuth = true;
  $mail->Username = ''; //Enter your mail Id
  $mail->Password = ''; //any password
  $mail->SMTPSecure = 'ssl';
  $mail->Port = 465;
  $mail->setFrom(""); //Enter your mail Id to send from
  $mail->addAddress($_POST['email']);
  $mail->Subject =''; // Subject of your mail
  $mail->Body = $_POST["remark"];
  if(!$mail->send())
  {
    echo 'Successful';
  }
}
?>