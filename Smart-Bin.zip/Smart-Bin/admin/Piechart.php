<?php
include("config/dbcon.php");
include('includes/header.php');
?>
<html>

<head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load("current", {
            packages: ["corechart"]
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {
            var data = google.visualization.arrayToDataTable([
                ['Bin_ID', 'Dry', 'Wet'],
                <?php
                $query = "select * from bins";
                $res = mysqli_query($con, $query);
                while ($data = mysqli_fetch_array($res)) {
                    $Bin_ID = $data['Bin_ID'];
                    $Dry = $data['Dry'];
                    $Wet = $data['Wet'];
                ?>['<?php echo $Bin_ID; ?>', <?php echo $Dry; ?>, <?php echo $Wet; ?>],
                <?php
                }
                ?>
            ]);

            var options = {
                title: 'Dry and Wet Usage',
                is3D: true,
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
            chart.draw(data, options);
        }
    </script>
</head>

<body>
    <div id="piechart_3d" style="width: 900px; height: 500px;"></div>
</body>

</html>
<?php
include('includes/footer.php');
include('includes/scripts.php');
?>