<?php
include('authentication.php');
include('includes/header.php');
?>
<style>
    .bg-custom-1{background-color:#293462;}
    .bg-custom-2{background-color:#D61C4E;}
    .bg-custom-3{background-color:#2B7A0B;}
    .bg-custom-4{background-color:#D1512D;}
#map1{
    width:100%;
    height:87.5vh;
}
</style>
<div id="map1"></div>
<script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js"></script>
<script src="js/mapscript.js"></script>
<?php
include('includes/footer.php');
include('includes/scripts.php');
?>