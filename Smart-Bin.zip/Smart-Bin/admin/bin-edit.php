<?php
include('authentication.php');
include('includes/header.php');
?>
<style>.borer{
    border: 3px solid black; 
    border-radius: 25px;}
</style>
<div class="container-fluid px-4">
    <h1 class="mt-4">Bins</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Admin</li>
        <li class="breadcrumb-item">Bin</li>
    </ol>
    <div class="row">
        <div class="col-md-12">
            <div class="card border">
                <div class="card-header">
                    <h4>Edit Bin</h4>
                </div>
                <div class="card-body">
                    <?php
                    if (isset($_GET['id'])) {
                        $user_id = $_GET['id'];
                        $users = "SELECT * FROM bins WHERE id='$user_id'";
                        $users_run = mysqli_query($con, $users);

                        if (mysqli_num_rows($users_run) > 0) {
                            foreach ($users_run as $user) {
                    ?>
                                <form action="code_bin.php" method="POST">
                                    <input type="hidden" name="id" value="<?=$user['id'];?>">
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="">Bin-Id</label>
                                            <input type="text" name="Bin_ID" value="<?= $user['Bin_ID']; ?> " class="form-control">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Dry</label>
                                            <input type="text" name="Dry" value="<?= $user['Dry']; ?> " class="form-control">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Wet</label>
                                            <input type="text" name="Wet" value="<?= $user['Wet']; ?> " class="form-control">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Area</label>
                                            <input type="text" name="Area" value="<?= $user['Area']; ?>"class="form-control">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Sub Area</label>
                                            <input type="text" name="Sub Area" value="<?= $user['Sub_Area']; ?>" class="form-control">
                                        </div>
                                       
                                        <div class="col-md-12 mb-3">
                                            <button type="submit" name="update_bin" class="btn btn-primary">Update Bin</button>
                                        </div>
                                    </div>
                                </form>
                            <?php
                            }
                        } else {
                            ?>
                            <h4>No Record Found</h4>
                    <?php
                        }
                    }
                    ?>
                </div>

            </div>
        </div>
    </div>
</div>




</div>

</div>

</div>

<?php

include('includes/footer.php');



?>