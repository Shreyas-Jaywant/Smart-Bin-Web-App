<?php
include('authentication.php');
include('includes/header.php');
?>
<div class="container-fluid px-4">
   
    <div class="row mt-4">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Add Bin
                    <a href="view-bin.php" class="btn btn-danger float-end">BACK</a></h4>
                </div>
                <div class="card-body">
                <form action="code_bin.php" method="POST">
                                    <input type="hidden" name="id" >
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="">Bin-Id</label>
                                            <input type="text" name="Bin_ID"  class="form-control">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Dry</label>
                                            <input type="text" name="Dry"  class="form-control">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Wet</label>
                                            <input type="text" name="Wet"  class="form-control">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Area</label>
                                            <input type="text" name="Area" class="form-control">
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="">Sub Area</label>
                                            
                                            <input type="text" name="Sub_Area" class="form-control">
                                        </div>
                                       
                                        <div class="col-md-12 mb-3">
                                            <button type="submit" name="add_bin" class="btn btn-primary">Add Bin</button>
                                        </div>
                                    </div>
                                </form>
                </div>
</div>
</div>
</div>
</div>
<?php
include('includes/footer.php');
?>