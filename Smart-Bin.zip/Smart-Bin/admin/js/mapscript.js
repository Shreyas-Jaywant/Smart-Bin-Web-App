let mapOptions = {
    center:[19.0336, 72.8538],
    zoom:13
}


let map = new L.map('map1' , mapOptions);
let layer = new L.TileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
map.addLayer(layer);

let marker = new L.Marker([19.0267, 72.8764]);
marker.addTo(map);


let marker3 = new L.Marker([19.0182,72.8407]);
marker3.addTo(map);
