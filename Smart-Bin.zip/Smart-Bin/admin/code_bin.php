<?php
include('authentication.php');

if(isset($_POST['bin_delete']))
{
    $user_id = $_POST['bin_delete'];

    $query="DELETE FROM bins WHERE id='$user_id' ";
    $query_run= mysqli_query($con,$query);
    
    if($query_run)
    {
        $_SESSION['message']="Delete Successfully";
        header("Location: view-bin.php");
        exit(0);
    }
    else
     {
        $_SESSION['message']="Something went wrong!!!";
        header("Location: view-bin.php");
        exit(0);
    }
}

if(isset($_POST['add_bin']))
{
    $Bin_ID = $_POST['Bin_ID'];
    $Dry = $_POST['Dry'];
    $Wet = $_POST['Wet'];
    $Area = $_POST['Area'];
    $Sub_Area = $_POST['Sub_Area'];

    $query ="INSERT INTO bins (Bin_ID,Dry,Wet,Area,Sub_Area) VALUES ('$Bin_ID','$Dry','$Wet','$Area','$Sub_Area')";
    $query_run=mysqli_query($con,$query);
    if($query_run)
    {
        $_SESSION['message']="Bin Added Successfully";
        header("Location: view-bin.php");
        exit(0);
    }
    else
     {
        $_SESSION['message']="Something went wrong!!!";
        header("Location: view-bin.php");
        exit(0);
    }
}

if(isset($_POST['update_bin']))
{
    $user_id=$_POST['id'];
    $Bin_ID=$_POST['Bin_ID'];
    $Dry = $_POST['Dry'];
    $Wet = $_POST['Wet'];
    $Area = $_POST['Area'];
    $Sub_Area = $_POST['Sub_Area'];
    $query ="UPDATE bins SET Bin_ID='$Bin_ID', Dry='$Dry', Wet='$Wet', Area='$Area', Sub_Area='$Sub_Area'
    WHERE id='$user_id' ";
    $query_run=mysqli_query($con,$query);
    if($query_run)
    {
        $_SESSION['message']="Updated Successfully";
        header('Location: view-bin.php');
        exit(0);
    }
   
}

?>