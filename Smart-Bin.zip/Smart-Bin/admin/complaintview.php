<?php
include('authentication.php');
include('includes/header.php');
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Complaint</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">List</li>
        <li class="breadcrumb-item">Complaints</li>
    </ol>
    <div class="row">
        <div class="col-md-12">
            <?php include('message.php') ?>
            <div class="card">
                <div class="card-header">
                    <h4>Registered Complaints
                   
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th><center>ID</center></th>
                                <th><center>Area</center></th>
                                <th><center>Complaints</center></th>
                                 <th><center>Status</center></th>
                                 <th><center>Action</center></th>
                                </tr>
                        </thead>
                        <tbody>
                        <?php
                            $query = "SELECT * FROM Complaints";
                            $query_run = mysqli_query($con, $query);
                            if (mysqli_num_rows($query_run) > 0) {
                                foreach ($query_run as $row) {
                            ?>
                                    <tr>
                                        <td><center><?= $row['ID'] ?></center></td>
                                         <td><center><?= $row['Area'] ?></center></td>
                                        <td><center><?= $row['complaint'] ?></center></td>
                                       
                                        <td><center><button type="button" class="btn btn-danger">Not process yet</center></button></td>
                                        <td>   <center><a href="complaint_details.php?ID=<?php echo htmlentities($row['ID']);?>"> View Details</a> </center></td>
                                    </tr>
                                    <?php }
                                    }
                                    else{
                                        ?>
                                        <tr>
                                    <td colspan="6">No Record Found</td>
                                </tr>
                                <?php
                                    }
                                    ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
include('includes/footer.php');
include('includes/scripts.php');
?>