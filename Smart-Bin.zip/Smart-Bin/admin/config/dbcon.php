<?php
$host="localhost";
$username="id";
$password="password";
$database="db";
$con = mysqli_connect("$host","$username","$password","$database");
//if(!$con)
//{
//    header("Location: ../errors/dberror.php");
//    die();
//}
?>