<style>
    .sb-sb-sidenav-dark {
        background: #59b6ec61;
    }
   
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
  
   text-align: center;
}

</style>
<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading"></div>
                <a class="nav-link" href="index.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <a class="nav-link" href="view-register.php">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Registered Staff
                </a>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayout1" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fa fa-envelope-open"></i></div>
                    BINS
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayout1" aria-labelledby="headingThree" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                    <a class="nav-link" href="view-bin.php">All Bins</a>
                <a class="nav-link" href="frequently_used.php">Frequently Used</a>
                <a class="nav-link" href="rarely_used.php">Rarely Used</a>
                    </nav>
                </div>
                <div class="sb-sidenav-menu-heading">Statistic</div>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Graphs
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="charts2.php">Bin Occupancy</a>
                        <a class="nav-link" href="LineGraph.php">Occupancy Trends</a>
                    </nav>
                </div>
                 <div class="sb-sidenav-menu-heading">Manage Complaints</div>
                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayout" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fa fa-envelope-open"></i></div>
                    Complaints
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayout" aria-labelledby="headingTwo" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                    <a class="nav-link" href="not_process_com.php">Not Yet Procceess</a>
                <a class="nav-link" href="inprocess_com.php">In Proccess</a>
                <a class="nav-link" href="close_com.php">Closed</a>
                    </nav>
                </div>
                
            </div>
            <div class="footer">
                <div class="small">Logged in as: <b>Admin</b></div>
            </div>
    </nav>
</div>