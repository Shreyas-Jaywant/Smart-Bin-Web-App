    <style>
.font_color{color: aqua;}
     </style>
      </main>
       <footer class="py-2 bg-light mt-auto">
          <div class="container-fluid px-4">
             <div class="d-flex align-items-center justify-content-between small">
                <div class="font_color">Copyright &copy; Your Website 2022</div>
                    <div class="font_color">
                     <a href="#" class="font_color">Privacy Policy</a>
                     &middot;
                     <a href="#" class="font_color">Terms &amp; Conditions</a>
                     </div>
                    
                </div>
            </div>
        </footer>
    </div> 
</div>