<?php
include('authentication.php');
include('includes/header.php');
?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Active Bins</h1>
    
    <div class="row">
        <div class="col-md-12">
            <?php include('message.php') ?>
            <div class="card">
                <div class="card-header">
                   
                    <h4>Frequently used Bins </h4>
                    
                   
                </div>
               
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Bin-ID</th>
                                <th>Dry</th>
                                <th>Wet</th>                                
                                <th>Area</th>
                                <th>Sub-Area</th>
                                <th>View Details</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM bins where Dry>=80 && Wet>=80";
                            $query_run = mysqli_query($con, $query);
                            if (mysqli_num_rows($query_run) > 0) {
                                foreach ($query_run as $row) {
                            ?>
                                    <tr>
                                        <td><?= $row['id'] ?></td>
                                        <td><?= $row['Bin_ID'] ?></td>
                                        <td><?= $row['Dry'] ?></td>
                                        <td><?= $row['Wet'] ?></td>
                                        
                                        <td><?= $row['Area'] ?></td>
                                        <td><?= $row['Sub_Area'] ?></td>
                                        <td><a href="charts.php?id=<?=$row['id']?>">View Details 
                                            </a></td>
                                        
                                        <td><a href="bin-edit.php?id=<?=$row['id']?>" class="btn btn-success">Edit</a></td>
                                        <td>
                                        <form action="code_bin.php" method="POST">    
                                        <button type="submit" name="bin_delete" value="<?=$row['id'];?>" class="btn btn-danger">Delete</td>
                                        </form>

                                    </tr>
                                <?php
                                }
                            } 
                            else {
                                ?>
                                <tr>
                                    <td colspan="6">No Record Found</td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>


                </div>

            </div>



        </div>

    </div>

</div>

<?php

include('includes/footer.php');
include('includes/scripts.php');
?>