<?php
include('authentication.php');
include('includes/header.php');
?>
<script language="javascript" type="text/javascript">
var popUpWin=0;
function popUpWindow(URLStr, left, top, width, height)
{
 if(popUpWin)
{
if(!popUpWin.closed) popUpWin.close();
}
popUpWin = open(URLStr,'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+500+',height='+600+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
}

</script>
<div class="module">
							<div class="module-head">
								<h3>Complaints In Process</h3>
							</div>
							<div class="module-body table">


							
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" >
									<thead>
										<tr>
                                        <th>ID</th>
											<th>Area</th>
											<th>E-Mail</th>
											<th>Status</th>											
											<th>Action</th>
											
										
										</tr>
									</thead>
								
<tbody>
<?php 
$st='in process';
$query=mysqli_query($con, "SELECT * from complaints where STATUS='$st'");
while($row=mysqli_fetch_array($query))
{
?>										
										<tr>
											<td><?php echo htmlentities($row['ID']);?></td>
											<td><?php echo htmlentities($row['Area']);?></td>
											<td><?php echo htmlentities($row['email']);?></td>
										
											<td><button type="button" class="btn btn-warning">In Process</button></td>
											
											<td>   <a href="complaint_details.php?ID=<?php echo htmlentities($row['ID']);?>"> View Details</a> 
											</td>
											</tr>

										<?php  } ?>
										</tbody>
								</table>
							</div>
						</div>
                        <?php
include('includes/footer.php');
include('includes/scripts.php');
?>