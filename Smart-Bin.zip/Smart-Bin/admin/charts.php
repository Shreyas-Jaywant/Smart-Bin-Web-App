<?php 
include("config/dbcon.php");
include('includes/header.php');
?>
<html>
  <head>
  
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Bin_ID','Dry', 'Wet'],
         <?php 
         if (isset($_GET['id'])) {
          $user_id = $_GET['id'];
         $query="select * from bins where id='$user_id'";
         $res=mysqli_query($con,$query);
         while($data=mysqli_fetch_array($res)){
            $Bin_ID=$data['Bin_ID'];
            $Dry=$data['Dry'];
            $Wet=$data['Wet'];
            ?>
            ['<?php echo $Bin_ID;?>',<?php echo $Dry;?>,<?php echo $Wet;?>],
            <?php
             }
            }
             ?>
        ]);

        var options = {
          chart: {
            title: 'Smart Bin',
            subtitle: 'Dry and Wet Usage',
          },
          bars: 'vertical' // Required for Material Bar Charts.
        };

        var chart = new google.charts.Bar(document.getElementById('barchart_material'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
  </head>
  <body>
<center>
    <div id="barchart_material" style="width: 400px; height: 600px;"></div>
    </center>
  </body>
</html>
<?php
include('includes/footer.php');
include('includes/scripts.php');
?>
