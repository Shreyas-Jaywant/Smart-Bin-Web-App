<?php
$host="localhost";
$username="root";
$password="";
$database="bin";
$con = mysqli_connect("$host","$username","$password","$database");
if(!$con)
{
    die("Error Login");
}
$response=array();

$sql_query="select * from charts";
$result=mysqli_query($con,$sql_query);

if(mysqli_num_rows($result)>0)
{
    while($row=mysqli_fetch_assoc($result))
    {
        array_push($response,$row);
    }
}
else
{
    $response['success']=0;
    $response['message']='No Data';
}
echo json_encode($response);
mysqli_close($con);
?>