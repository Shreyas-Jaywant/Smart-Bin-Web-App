<?php
include('authentication.php');

if(isset($_POST['user_delete']))
{
    $user_id = $_POST['user_delete'];

    $query="DELETE FROM users WHERE id='$user_id' ";
    $query_run= mysqli_query($con,$query);
    
    if($query_run)
    {
        $_SESSION['message']="Delete Successfully";
        header("Location: view-register.php");
        exit(0);
    }
    else
     {
        $_SESSION['message']="Something went wrong!!!";
        header("Location: view-register.php");
        exit(0);
    }
}

if(isset($_POST['add_user']))
{
    $Fname = $_POST['Fname'];
    $Lname = $_POST['Lname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role_as = $_POST['role_as'];
    //$status = $_POST['status']== true ? '1': '0';

    $query ="INSERT INTO users (Fname,Lname,email,password,role_as) VALUES ('$Fname','$Lname','$email','$password','$role_as')";
    $query_run=mysqli_query($con,$query);
    if($query_run)
    {
        $_SESSION['message']="Admin/User Added Successfully";
        header("Location: view-register.php");
        exit(0);
    }
    else
     {
        $_SESSION['message']="Something went wrong!!!";
        header("Location: view-register.php");
        exit(0);
    }
}

if(isset($_POST['update_user']))
{
    $user_id=$_POST['user_id'];
    $Fname = $_POST['Fname'];
    $Lname = $_POST['Lname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role_as = $_POST['role_as'];
    $status = isset($_POST['status'])?1:0;
    $query ="UPDATE users SET Fname='$Fname',Lname='$Lname',email='$email',
    password='$password', role_as='$role_as' 
    WHERE id='$user_id' ";//,status='$status'
    $query_run=mysqli_query($con,$query);
    
    if($query_run)
    {
        $_SESSION['message']="Updated Successfully";
        header('Location: view-register.php');
        exit(0);
    }
}

?>