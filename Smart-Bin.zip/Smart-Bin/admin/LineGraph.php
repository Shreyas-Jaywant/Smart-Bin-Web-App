  <?php
    include("config/dbcon.php");
    include('includes/header.php');
    ?>
  <html>
<style>
    .vertical-center {
  margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}
.container {
  height: 100%;
  position: absolute;
  
}
</style>
    

  <body>
      
      <center>
          <div class="container" >
          <div class="vertical-center" >
      <br><br>
      <iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1971965/charts/1?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=Dry&type=line"></iframe>
        <iframe width="450" height="260" style="border: 1px solid #cccccc;" src="https://thingspeak.com/channels/1971965/charts/2?bgcolor=%23ffffff&color=%23d62020&dynamic=true&results=60&title=Wet&type=line"></iframe>
        </div>
        </div>
</center>
  </body>

  </html>
  <?php
    include('includes/footer.php');
    include('includes/scripts.php');
    ?>