<?php
include('authentication.php');
include('includes/header.php');
?>
<div class="module">
							<div class="module-head">
								<h3>Closed Complaints</h3>
							</div>
							<div class="module-body table">


							
								<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" >
									<thead>
										<tr>
                                        <th>ID</th>
											<th>Area</th>
											<th>E-mail</th>
											<th>Status</th>											
											<th>Action</th>
										
										</tr>
									</thead>
								
<tbody>
<?php 
$st='closed';
$query=mysqli_query($con, "select * from complaints where STATUS='$st'");
while($row=mysqli_fetch_array($query))
{
?>										
										<tr>
											<td><?php echo htmlentities($row['ID']);?></td>
											<td><?php echo htmlentities($row['Area']);?></td>
											<td><?php echo htmlentities($row['email']);?></td>
										
											<td><button type="button" class="btn btn-success">Closed</button></td>
											
											<td>   <a href="complaint_details.php?ID=<?php echo htmlentities($row['ID']);?>"> View Details</a> 
											</td>
											</tr>

										<?php  } ?>
										</tbody>
								</table>
							</div>
						</div>		
                        <?php
include('includes/footer.php');
include('includes/scripts.php');
?>