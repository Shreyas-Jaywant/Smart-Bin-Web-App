
<?php
include('includes/header.php');
$host="localhost";
$username=""; //Enter Your username
$password=""; //Enter Your password
$database=""; //Enter Your db
$con = mysqli_connect("$host","$username","$password","$database");

$wet=$_GET["WET"];
$dry=$_GET["DRY"];
$query="Insert into LIVEDATA(WET,DRY) values('$wet','$dry')";
$result=mysqli_query($con,$query);
echo "Data Updated";
?>

<?php

include('includes/footer.php');
include('includes/scripts.php');
?>