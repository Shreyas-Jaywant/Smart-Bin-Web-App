<?php 
include('authentication.php');
include('includes/header.php');
?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
           
                <div class="card-body">
                    <form action="" method="POST">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" name="filter_value" class="form-control" placeholder="Search Data"> 
                                </div>
                            </div>
                            <div class="col-md-6">
                                <button type="submit" name="filter_btn" class="btn btn-primary" >Search</button>
                                <a href="view-bin.php" class="btn btn-primary">Back</a>
                            </div>
                        </div>
                    </form>
                    <table class="table">
                        <thead>
                            <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Bin-ID</th>
                            <th scope="col">Dry</th>
                            <th scope="col">Wet</th>
                            <th scope="col">Area</th>
                            <th scope="col">Sub Area</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                                
                                if(isset($_POST['filter_btn']))
                                {
                                    $value_filer=$_POST['filter_value'];
                                    $query="SELECT * FROM bins WHERE CONCAT(BIN_ID,Dry,Wet,Area,Sub_Area) like '%$value_filer%'";
                                    $query_run=mysqli_query($con,$query);
                                    if(mysqli_num_rows($query_run)>0)
                                    {
                                        while($row=mysqli_fetch_array($query_run))
                                        {
                                            ?>
                                            <tr>
                                                <th ><?= $row['id'] ?></th>
                                                <th ><?= $row['Bin_ID'] ?></th>
                                                <th ><?= $row['Dry'] ?></th>
                                                <th ><?= $row['Wet'] ?></th>
                                                <th ><?= $row['Area'] ?></th>
                                                <th ><?= $row['Sub_Area'] ?></th>
                                                </tr>
                                                <?php

                                        }
                                    }
                                
                                else
                                {
                                    ?><tr>
                                        <td colspan="6">No Data Found</td>
                                    </tr>
                                    <?php
                                }
                            }
                            ?>
                            
                            
                            
                        </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>
</div>