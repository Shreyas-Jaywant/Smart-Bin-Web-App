<?php
session_start();
include('admin/config/dbcon.php');
if(isset($_POST['register_btn']))
{
    $Fname=mysqli_real_escape_string($con,$_POST['Fname']);
    $Lname=mysqli_real_escape_string($con,$_POST['Lname']);
    $email=mysqli_real_escape_string($con,$_POST['email']);
    $password=mysqli_real_escape_string($con,$_POST['password']);
    $confirl_password=mysqli_real_escape_string($con,$_POST['Cpassword']);
    if($password==$confirl_password)
    {
        $checkmail="SELECT email FROM users WHERE email='$email'";
        $checkmail_run=mysqli_query($con,$checkmail);
        if(mysqli_num_rows($checkmail_run)>0)
        {
            $_SESSION['message']="Already Email Exists";
            header("Location: register.php");
            exit(0);
        }
        else{
            $user_query= "INSERT INTO users(Fname,	Lname,	email,	password) VALUES('$Fname','$Lname','$email','$password')";
            $user_query_run=mysqli_query($con,$user_query);
            if($user_query)
            {
                $_SESSION['message']="Registered Successful";
                header("Location: login.php");
                exit(0);
            }
            else
            {
                $_SESSION['message']="Something went wrong";
                header("Location: register.php");
                exit(0);  
            }
        }
    }
    else
    {
        $_SESSION['message']="password and confirm password doest not match";
        header("Location: register.php");
        exit(0);
    }
}
else
{
    header('Location: register.php');
    exit(0);
}
