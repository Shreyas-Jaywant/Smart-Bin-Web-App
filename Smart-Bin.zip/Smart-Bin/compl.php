<?php
$con=mysqli_connect("localhost", "id", "password", "db");
if(!$con)
{
    die("DataBase Connection Failed" .mysqli_error($con));
    exit();
}
$db = "db";
$dbs = mysqli_select_db($con,$db);  
if(!$dbs)
{
    die("Database Selection Failed :" .mysqli_error($con));;
    exit();
}
$ID=mysqli_real_escape_string($con,$_GET['Id']);
$Area=mysqli_real_escape_string($con,$_GET['Area']);
$COMP=mysqli_real_escape_string($con,$_GET['comp']);
$query= "INSERT INTO com(Id,Area,comp) VALUES (null,'$Area','$COMP')";
if(mysqli_query($con,$query))
{
    echo "Record Added Successfully ";
}
else
{
    echo "Error: Could not able to execute" .$query." ".mysqli_error($con); 
}
mysqli_close($con);
?>
