let mapOptions = {
    center:[19.0392,72.8297],
    zoom:13
}


let map = new L.map('map1' , mapOptions);
let layer = new L.TileLayer('http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
map.addLayer(layer);

let marker = new L.Marker([19.0284,72.8751]);
marker.addTo(map);

let marker1 = new L.Marker([19.0325,72.8717]);
marker1.addTo(map);

let marker2 = new L.Marker([18.9977, 72.8376]);
marker2.addTo(map);

let marker3 = new L.Marker([19.0182,72.8407]);
marker3.addTo(map);
