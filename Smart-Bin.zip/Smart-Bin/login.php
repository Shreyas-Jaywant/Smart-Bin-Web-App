<?php
session_start();
if (isset($_SESSION['auth'])) {
    if (!isset($_SESSION['message'])) {
        $_SESSION['message'] = "You are already logged In";
    }

    header("Location: index.php");
    exit(0);
}
include('includes/header.php');
include('includes/navbar.php');

?>
<style>
    .btn-sm {
        
        padding: 0.25rem 0.5rem;
        font-size: .875rem;
        line-height: 1.5;
        border-radius: 5rem;
    }
    .btn-block{ 
        display: block;
        width: 100%;
    } 
    

    .col-md-4 {
        flex: 0 0 33.333333%;
        max-width: 33.333333%;
    }
    .btn-primary{
        color: #fff;
        background-color: #007bff;
        border-color: #007bff;
    }
     
    
    
    
body{
    width: 100%;
    height: calc(100%);
    /*background: #007bff;*/
    
}
main#main{
    width:100%;
    height: calc(100%);
    background:white;
}
#login-right{
    position: absolute;
    right:0;
    width:40%;
    height: calc(100%);
    background:white;
    display: flex;
    align-items: center;
    
    
}

#login-left{
    position: absolute;
    left:0;
    width:60%;
    height: calc(92.7%);
    background:#59b6ec61;
    display: flex;
    align-items: center;
   
}
#login-right .card{
    margin: auto
}
.logo {
    height:70vh;
    width:60%;
margin: auto;
font-size: 8rem;
background:#000;
padding: 0em 0em;
border-radius: 50% 50%;
color: #000000b3;

}
.btn span.fa {         
  opacity: 0;       
}
.btn.active span.fa {        
  opacity: 1;       
}
.laundry-logo {
    width: 2em;
    height: 2em;
}

.form-control {
    display: block;
    width: 100%;
    height: calc(1.5em + 0.75rem + 2px);
    padding: 0.375rem 0.75rem;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}
.form-group {
    margin-bottom: 1rem;
}
.form-control{
    border-radius: 150px;
    border: 1px solid black;
}
.card{
    border: hidden;
}
/*.card-body{
    border: 3px solid black; 
    border-radius: 25px;
}*/

</style>

<div id="login-left">
  			<div class="logo">
  				<div class="laundry-logo"><img src="dump1.png"></div>
  			</div>
  		</div>
  		<div id="login-right" >
  			<div class="card col-md-8">
              <?php include('message.php'); ?>
  				<div class="card-body">
                    <div><center><img src="profile.jpg"></center></div>
                  <form action="logincode.php" method="POST">
  						<div class="form-group">
  							<label for="username" class="control-label">  <i class='bx bx-envelope' id="btn" ></i>Email ID</label>
  							<input type="email"  name="email" class="form-control" required>
  						</div>
  						<div class="form-group">
  							<label for="password" class="control-label"> <i class='bx bx-lock-alt' id="btn" ></i>Password</label>
  							<input type="password" name="password" class="form-control" required>
  						</div>
  						<center><button type="submit" name="login_btn" class="btn-sm btn-block btn-wave col-md-4 btn-primary">Login</button></center>
  					</form>
  				</div>
  			</div>
  		</div>
  
    <?php
    include('includes/footer.php');
    
    ?>