
<?php
$host="localhost";
$username="id";
$password="password";
$database="db";
$con = mysqli_connect("$host","$username","$password","$database");
/*if(!$con)
{
    die("DataBase Connection Failed" .mysqli_error($con));
    exit();
}*/
$db = "db";
$dbs = mysqli_select_db($con,$db);  
if(!$dbs)
{
    die("Databaase Selection Failed :" .mysqli_error($con));;
    exit();
}
$ID=mysqli_real_escape_string($con,$_GET['ID']);
$lat=mysqli_real_escape_string($con,$_GET['lat']);
$long=mysqli_real_escape_string($con,$_GET['longitude']);
//$complaint=mysqli_real_escape_string($con,$_GET['complaint']);
$query= "update lat_long set lat='$lat',longitude='$long' where ID=1";
//printf("<p>ID of the previous record: %d.</p>",$mysqli->insert_id);
if(mysqli_query($con,$query))
{
    echo "Record Added Successfully ";
}
else
{
    echo "Error: Could not able to execute" .$query." ".mysqli_error($con); 
}
mysqli_close($con);
?>
