
<?php
include('includes/header.php');
include('includes/navbar.php');

?>
<style>
    .w3-justify{font-size:20px; font-weight: bold;}
    .location{
			width: 40%;
			float: left;
			margin-left: 40px;
			margin-right: 30px;
			margin-top: 35%;

		}
/*.back {
  
   background-image: url("back1.png");
   background-repeat: no-repeat, no-repeat;
    background-size: cover;
   height: 100%;
   background-position: center;
}*/
.height{ background-color:orange}
</style>


<div class="height">
    <div class='back'>
        <div class="w3-container w3-content w3-center w3-padding-64" style="max-width:800px" id="band">
            <h2 class="w3-wide">SMART BIN</h2>
            <p class="w3-opacity"><i>SWACCH BHARAT</i></p>
            <p><b>Hardware Components</b></p> 
            <p class="w3-justify">This is a Waste Segregation Dustbin, We have created a small scale mini project to demonstrate the working of smart dustbin using the concepts of Embedded System and the tools like Arduino and sensors has been used. This will segregate the dry and the wet garbage in there respective compartments.
            </p>
           <p><b> <b>Software Components</b></b></p>
           <p class="w3-justify">
              For enhancement we have created a Website and a Mobile Application. The website is used for representing the Admin Panel while the Mobile Application is for the user interface. 
           </p>
    
        </div>
    </div>
</div>
<?php
include('includes/footer1.php');
?>