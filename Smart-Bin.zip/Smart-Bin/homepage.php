<?php
include('includes/header.php');
include('includes/navbar.php');

?>
<style>
.img_box img{
    max-width: 137.8vh;
    max-height: 1000vh;
}
.card_slider{
    padding: 0 0px;
}
.back{background-color:#021B79}
</style>
<div class="back">
<section class="slider_container">
    <center>
    <div class="conatiner">
        <div class="swiper card_slider">
            <div class="swiper-wrapper">
                
                <div class="swiper-slide">
                    <div class="img_box">
                        <img src="img/swipe-2.jpg">
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="img_box">
                        <img src="img/swipe-3.jpg">
                    </div>
                </div>
            </div>
            <div class="swiper-button-next"></div>
             <div class="swiper-button-prev"></div>
            <div class="swiper-pagination"></div>
        </div>
    </div>
    </center>
</section>
</div>

<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script>
var swiper = new Swiper(".card_slider", {
    cssMode: true,
        loop:true,
     
        autoplay:{delay:1500,},
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
        breakpoints: {
          320: {
            slidesPerView: 1,
           
          },
          768: {
            slidesPerView: 1,
          
          },
          
        },
        pagination: {
          el: ".swiper-pagination",
          clickable:true,
        },
        mousewheel: true,
        keyboard: true,
      });
</script>